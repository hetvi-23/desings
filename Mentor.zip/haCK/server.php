<?php
session_start();

// initializing variables
$FNAME = "";
$LNAME="";
$PHONE="";
$EMAIL="";
$QUALIFICATION="";
$USER_NAME="";
$PASSWORD="";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'mentor');


// REGISTER USER
if (isset($_POST['reg_user'])) {
  // receive all input values from the form
  $FNAME = mysqli_real_escape_string($db, $_POST['FNAME']);
  $LNAME = mysqli_real_escape_string($db, $_POST['LNAME']);
  $PHONE = mysqli_real_escape_string($db, $_POST['PHONE']);
  $EMAIL = mysqli_real_escape_string($db, $_POST['EMAIL']);
  $QUALIFICATION = mysqli_real_escape_string($db, $_POST['QUALIFICATION']);
  $USER_NAME = mysqli_real_escape_string($db, $_POST['USER_NAME']);
  
  $PASSWORD= mysqli_real_escape_string($db, $_POST['PASSWORD']);
  

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($USER_NAME)) { array_push($errors, "Username is required"); }
  if (empty($EMAIL)) { array_push($errors, "Email is required"); }
  if (empty($PASSWORD_1)) { array_push($errors, "Password is required"); }
  
  }

  // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM users WHERE USER_NAME='$USER_NAME' OR EMAIL='$EMAIL' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['USER_NAME'] === $USER_NAME) {
      array_push($errors, "Username already exists");
    }

    if ($user['EMAIL'] === $EMAIL) {
      array_push($errors, "email already exists");
    }
  }

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {
  	$PASSWORD = md5($PASSWORD_1);//encrypt the password before saving in the database

  	$query = "INSERT INTO users (USER_NAME, EMAIL, PASSWORD) 
  			  VALUES('$USER_NAME', '$EMAIL', '$PASSWORD')";
  	mysqli_query($db, $query);
  	$_SESSION['USER_NAME'] = $USER_NAME;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: index.php');
  }
}

// LOGIN USER
if (isset($_POST['login_user'])) {
  $USER_NAME = mysqli_real_escape_string($db, $_POST['USER_NAME']);
  $PASSWORD = mysqli_real_escape_string($db, $_POST['PASSWORD']);

  if (empty($USER_NAME)) {
  	array_push($errors, "Username is required");
  }
  if (empty($PASSWORD)) {
  	array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
  	$PASSWORD = md5($PASSWORD);
  	$query = "SELECT * FROM users WHERE USER_NAME='$USER_NAME' AND PASSWORD='$PASSWORD'";
  	$results = mysqli_query($db, $query);
  	if (mysqli_num_rows($results) == 1) {
  	  $_SESSION['USER_NAME'] = $USER_NAME;
  	  $_SESSION['success'] = "You are now logged in";
  	  header('location: index.php');
  	}else {
  		array_push($errors, "Wrong username/password combination");
  	}
  }
}

?>